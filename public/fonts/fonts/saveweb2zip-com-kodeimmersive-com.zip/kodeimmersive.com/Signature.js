const micheliniStyles = 'padding: 10px; color: #fff; background-color: #ff2c2c;'
const malvahStyles = 'padding: 10px; color: #fff; background-color: #171717;'

console.clear()
console.log('')
console.log( 'Developed by')
console.log('%cfrancescomichelini.com', micheliniStyles)
console.log('')
console.log( 'Designed by')
console.log('%cmalvah.co', malvahStyles)
console.log('')
